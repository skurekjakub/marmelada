﻿using System.Web.Mvc;
using System.Web.Routing;

using Kentico.Web.Mvc;

namespace MedioMVC
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            // Enables and configures the selected Kentico ASP.NET MVC integration features for the MedioMVC application
            ApplicationConfig.RegisterFeatures(ApplicationBuilder.Current);
        }
    }
}
