﻿namespace MedioMVC.Models.Menu
{
    public class MenuItemViewModel
    {
        // Defines the properties of the MenuItem view model
        public string MenuItemText { get; set; }
        public string MenuItemRelativeUrl { get; set; }
    }
}