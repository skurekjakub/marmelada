﻿namespace MedioMVC.Models.MedicalCenter
{
    public class MedicalCenterViewModel
    {
        // Defines the properties of the MedicalCenter view model
        public string DocumentName { get; set; }
        public string MedicalCenterHeader { get; set; }
        public string MedicalCenterText { get; set; }

        // Maps the data from the MedicalCenter page type's fields to the view model properties
        public MedicalCenterViewModel(CMS.DocumentEngine.Types.MEDIO.MedicalCenter medicalCenterPage)
        {
            DocumentName = medicalCenterPage.DocumentName;
            MedicalCenterHeader = medicalCenterPage.Fields.Header;
            MedicalCenterText = medicalCenterPage.Fields.Text;
        }
    }
}