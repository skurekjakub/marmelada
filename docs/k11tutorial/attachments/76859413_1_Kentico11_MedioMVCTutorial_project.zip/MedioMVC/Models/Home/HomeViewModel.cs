﻿namespace MedioMVC.Models.Home
{
    public class HomeViewModel
    {
        // Defines the properties of the Home view model
        public string DocumentName { get; set; }
        public string HomeHeader { get; set; }
        public string HomeTextHeading { get; set; }
        public string HomeText { get; set; }


        // Maps the data from the Home page type's fields to the view model properties
        public HomeViewModel(CMS.DocumentEngine.Types.MEDIO.Home homePage)
        {
            DocumentName = homePage.DocumentName;
            HomeHeader = homePage.Fields.Header;
            HomeTextHeading = homePage.Fields.TextHeading;
            HomeText = homePage.Fields.Text;
        }
    }
}