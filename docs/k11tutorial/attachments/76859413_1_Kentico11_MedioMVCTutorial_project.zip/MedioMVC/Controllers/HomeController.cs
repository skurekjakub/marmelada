﻿using System.Web.Mvc;

using CMS.DocumentEngine.Types.MEDIO;
using CMS.SiteProvider;

using MedioMVC.Models.Home;

namespace MedioMVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Loads and displays the site's Home page
        public ActionResult Index()
        {
            // Retrieves the Home page using the 'GetHome' method from the page type's generated provider
            Home homeNode = HomeProvider.GetHome("/Home", "en-us", SiteContext.CurrentSiteName)
                                        .Columns("DocumentName", "HomeHeader", "HomeTextHeading", "HomeText");

            // Creates a new HomeViewModel instance based on the page data
            var homeModel = new HomeViewModel(homeNode);

            return View(homeModel);
        }
    }
}