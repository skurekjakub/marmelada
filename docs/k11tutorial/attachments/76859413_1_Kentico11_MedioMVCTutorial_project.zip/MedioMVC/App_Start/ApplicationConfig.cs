using Kentico.Web.Mvc;
using Kentico.Content.Web.Mvc;

namespace MedioMVC
{
    public class ApplicationConfig
    {
        public static void RegisterFeatures(ApplicationBuilder builder)
        {
            builder.UseDataAnnotationsLocalization();
            builder.UseNotFoundHandler();
            // Enables the Preview mode functionality, which allows your website editors to preview
            // the content of the MVC site's pages from the Kentico user interface.
            builder.UsePreview();

        }
    }
}
